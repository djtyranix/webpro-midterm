

<?php $__env->startSection('content'); ?>
<div class="container">
<form method="POST" action="<?php echo e(route('update_reply')); ?>">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <input type="hidden" class="form-control" name ="id" value="<?php echo e($answer->id); ?>">
    <input type="hidden" class="form-control" name ="question_id" value="<?php echo e($answer->question_id); ?>">
    <div class="form-group">
        <label for="formGroupExampleInput2">Description</label>
        <input type="text" class="form-control" name="the_answer" placeholder="Another input" value="<?php echo e($answer->the_answer); ?>">
    </div>
    <button class="btn btn-warning">
        <?php echo e(__('Update')); ?>

    </button>

</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\readit\resources\views/editreply.blade.php ENDPATH**/ ?>