

<?php $__env->startSection('content'); ?>


<div class="container">
<form method="POST" action="<?php echo e(route('ask')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="formGroupExampleInput">Title</label>
        <input type="text" class="form-control" name ="title_question" placeholder="Example input">
    </div>

    <div class="form-group">
        <label for="formGroupExampleInput2">Description</label>
        <input type="text" class="form-control" name="detail_question" placeholder="Another input">
    </div>

    <button class="btn btn-primary">
        <?php echo e(__('Submit')); ?>

    </button>

</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\readit\resources\views/insertquestion.blade.php ENDPATH**/ ?>