
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/mystyle.css')); ?>" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
    <script>
      function load()
      {
         document.frm1.submit()
      }
      </script>
</head>
<body onload="load()">
    <div id="app">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
            <div class="container">


            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                
                    <i class="fa fa-home"></i>
                    <?php echo e(config('app.name', 'Readit')); ?>

                </a>
                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    

                                    <a class="dropdown-item" href="<?php echo e(route('userquestion')); ?>">
                                        <?php echo e(__('My Question')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('useranswer')); ?>">
                                        <?php echo e(__('My Answer')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
   

   <form action="<?php echo e(route('thread')); ?>" method = "POST" id="frm1" name="frm1">
      <?php echo csrf_field(); ?>
      <input type="hidden" name ="id" value="<?php echo e($id_question); ?>">
   </form>
   <main class="py-4">
      <!-- Title Bar + Mini-Info -->
<div class="container mt-4 mb-3">
   <div class="row justify-content-start">
       <div class="col-md-12" style="padding-left: 2rem;">
           <h1><?php echo e($questions->title_question); ?><span style="color: #B8B8B8;"> #<?php echo e(sprintf('%06d', $questions->id)); ?></span></h1>
           Posted by <a href="javascript:void(0)"><?php echo e($questions->name); ?></a> | Last edit <?php echo e(Carbon\Carbon::parse($questions->updated_at)->timezone("Asia/Jakarta")->format('M d, Y')); ?> at <?php echo e(Carbon\Carbon::parse($questions->updated_at)->timezone("Asia/Jakarta")->format('H:i')); ?> |
               <?php if($count > 1): ?>
                   <?php echo e($count); ?> replies
               <?php else: ?>
                   <?php echo e($count); ?> reply
               <?php endif; ?>
       </div>
   </div>
</div>

<!-- Fetching question -->
<div class="container">
   <div class="row align-items-start">
       <div class="col-md-12">
           <div class="card mb-4">
               <div class="card-body">
                   <div class="forum-content user-detail">
                       <div class="container">
                           <center><img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar rounded-circle img-thumbnail" alt="avatar" style="width: 7em;"></center>
                       </div>
                       <div class="mt-2">
                           <a href="javascript:void(0)"><center><?php echo e($questions->name); ?></center></a>
                       </div>
                       <div>Member since <strong><?php echo e(Carbon\Carbon::parse($questions->user_created_at)->timezone("Asia/Jakarta")->format('M d, Y')); ?></strong></div>
                   </div>
                   <div class="forum-content content-detail">
                       <div style="font-size: .7rem;">
                           Edited <?php echo e(Carbon\Carbon::parse($questions->updated_at)->timezone("Asia/Jakarta")->format('M d, Y')); ?>

                       </div>
                       <hr class="w-100">
                       <div style="font-size: 1.1rem;">
                           <?php echo e($questions->detail_question); ?>

                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>
</div>

<?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row align-items-start">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="forum-content user-detail">
                        <div class="container">
                            <center><img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar rounded-circle img-thumbnail" alt="avatar" style="width: 7em;"></center>
                        </div>
                        <div class="mt-2">
                            <a href="javascript:void(0)" data-abc="true"><center><?php echo e($answer->name); ?></center></a>
                        </div>
                        <div>Member since <strong><?php echo e(Carbon\Carbon::parse($answer->user_created_at)->timezone("Asia/Jakarta")->format('M d, Y')); ?></strong></div>
                    </div>
                    <div class="forum-content content-detail">
                        <div class="d-flex justify-content-between" style="font-size: .7rem;">
                            <div>
                                Edited <?php echo e(Carbon\Carbon::parse($answer->updated_at)->timezone("Asia/Jakarta")->format('M d, Y')); ?>

                            </div>
                            <div>
                                #<?php echo e($loop->iteration); ?>

                            </div>
                        </div>
                        <hr class="w-100">
                        <div style="font-size: 1.1rem;">
                            <?php echo e($answer->the_answer); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


   </main>
   <footer>
      <div class="footer w-100">

      </div>
      <div class="copyright w-100">
          <center>&copy; 2020 ReadIt. Proudly made with love.</center>
      </div>
  </footer>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
</body>
<?php /**PATH D:\xampp\htdocs\readit\resources\views/placeholder.blade.php ENDPATH**/ ?>