

<?php $__env->startSection('content'); ?>

<!-- <div class="container mt-4 mb-3">
    <div class="row justify-content-start">
        <div class="col-md-12" style="padding-left: 2rem;">
            <h1><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-fw" style="font-size: 2.7rem;"></i></a> <i class="fa fa-chevron-right fa-fw" style="font-size: 1rem; position:relative; top: -.3rem;" aria-hidden="true"></i> #<?php echo e(sprintf('%06d', $question->id)); ?> <i class="fa fa-chevron-right fa-fw" style="font-size: 1rem; position:relative; top: -.3rem;" aria-hidden="true"> Edit Thread</h1>
        </div>
    </div>
</div> -->

<div class="container mt-4 mb-3">
    <div class="row justify-content-start">
        <div class="col-md-12">
            <h1><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-fw" style="font-size: 2.7rem;"></i></a> <i class="fa fa-chevron-right fa-fw" style="font-size: 1rem; position:relative; top: -.3rem;" aria-hidden="true"></i> <a href="/thread/<?php echo e($question->id); ?>">#<?php echo e(sprintf('%06d', $question->id)); ?></a> <i class="fa fa-chevron-right fa-fw" style="font-size: 1rem; position:relative; top: -.3rem;" aria-hidden="true"></i> Edit Thread</h1>
        </div>
    </div>
</div>

<div class="container">
    <form method="POST" action="<?php echo e(route('update_thread')); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" class="form-control" name ="id" placeholder="Example input" value="<?php echo e($question->id); ?>">
        <div class="form-group">
            <label for="title_question">Title</label>
            <input type="text" class="form-control" name ="title_question" id ="title_question" value="<?php echo e($question->title_question); ?>">
        </div>
        <div class="form-group">
            <label for="detail_question">Description</label>
            <textarea class="form-control" name="detail_question" id="detail_question" cols="30" rows="8" placeholder="Edit your reply here" style="resize: none;"><?php echo e($question->detail_question); ?></textarea>
        </div>
        <button class="btn btn-warning">
            <?php echo e(__('Update')); ?>

        </button>
    </form>
</div>

<script>
    var currentTitle = 'Edit Thread: <?php echo e($question->title_question); ?>';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\readit\resources\views/edit.blade.php ENDPATH**/ ?>