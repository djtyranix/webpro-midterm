

<?php $__env->startSection('content'); ?>

<?php use \App\Http\Controllers\myProfileController; ?>

<div class="row mt-4 py-5">
    <div class="col-md-12">
        <div class="container">
            <div>
                <center><img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar rounded-circle img-thumbnail" alt="avatar" style="width: 12em;"></center>
            </div>
            <div>
                <h1 class="mt-2 mb-5"><center>Hello, <strong><?php echo e($myDetails->name); ?></strong></center></h1>
            </div>
        </div>
    </div>
</div>

<!-- CARD DECK -->
<div class="row">
    <div class="col-md-12">
        <div class="container">
            <div class="card-deck">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title mb-4"><center>Your <strong>Profile</strong></center></h3>
                        <p class="card-text mb-1"><small class="text-muted">Username</small></p>
                        <p class="card-text"><?php echo e($myDetails->name); ?></p>
                        <p class="card-text mb-1"><small class="text-muted">Login Email</small></p>
                        <p class="card-text"><?php echo e($myDetails->email); ?></p>
                        <p class="card-text mb-1"><small class="text-muted">Password</small></p>
                        <p class="card-text"><a href="<?php echo e(route('changepassword')); ?>">Change password</a></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title mb-4"><center>Your <strong>Thread</strong></center></h3>                        
                        <?php $__currentLoopData = $myQuestion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myQuestions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="mb-0"><a href="<?php echo e(route('thread', $myQuestions->id)); ?>"><?php echo e($myQuestions->title_question); ?></a></h5>
                            <p class="card-text mb-0"><small class="text-muted">
                                <?php if($myQuestions->updated_at > $myQuestions->created_at): ?>
                                    Last edit <?php echo e(Carbon\Carbon::parse($myQuestions->created_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                                <?php else: ?>
                                    Posted on <?php echo e(Carbon\Carbon::parse($myQuestions->updated_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                                <?php endif; ?></small></p>
                            <p class="card-text mb-4"><small class="text-muted"><?php echo e(myProfileController::countReplies($myQuestions->id)); ?> 
                            <?php if(myProfileController::countReplies($myQuestions->id) > 1): ?>
                                replies
                            <?php else: ?>
                                reply    
                            <?php endif; ?>
                            </small></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($questionCount > 5): ?>
                            <a href="<?php echo e(route('userquestion')); ?>">See more</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title mb-4"><center>Your <strong>Reply</strong></center></h3>
                        <?php $__currentLoopData = $myAnswer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myAnswers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="mb-0"><a href="<?php echo e(route('thread', $myAnswers->question_id)); ?>/#<?php echo e(sprintf('%06d', $myAnswers->id)); ?>">Reply #<?php echo e(sprintf('%06d', $myAnswers->id)); ?></a></h5>
                            <p class="card-text mb-0"><small class="text-muted">Thread: <?php echo e($myAnswers->title_question); ?></small></p>
                            <p class="card-text mb-4"><small class="text-muted">
                                <?php if($myAnswers->updated_at > $myAnswers->created_at): ?>
                                Last edit <?php echo e(Carbon\Carbon::parse($myAnswers->created_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                            <?php else: ?>
                                Posted on <?php echo e(Carbon\Carbon::parse($myAnswers->updated_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                            <?php endif; ?></small></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($answerCount > 5): ?>
                            <a href="<?php echo e(route('useranswer')); ?>">See more</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var currentTitle = 'My Profile';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webpro-midterm\resources\views/myprofile.blade.php ENDPATH**/ ?>