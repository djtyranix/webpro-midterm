

<?php $__env->startSection('content'); ?>

<div class="container mt-5 mb-3">
    <div class="row justify-content-between">
        <div class="col-3">
            <h2>My <strong>Question</strong></h2>
        </div>
    </div>
    <div class="row justify-content-end">
        <div></div>
    </div>
</div>

<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-hoverable mb-4">
                <div class="card-body">     
                    <a style="text-decoration: none; color: #000;" class="stretched-link" href="<?php echo e(route('thread', $question->id)); ?>">
                        <div class="media flex-wrap w-100 align-items-center">
                            <div class="media-body truncate">
                                <h2><strong><?php echo e($question->title_question); ?></strong></h2>
                                <div class="text-muted">
                                    Posted on <?php echo e(Carbon\Carbon::parse($question->created_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                                    <?php if($question->updated_at > $question->created_at): ?>
                                     | Last edit <?php echo e(Carbon\Carbon::parse($question->updated_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                                   <?php endif; ?>
                                </div>
                            </div>
                        </div>              
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Pagination -->
<div class="row">
    <div class="col-md-12">
        <div class="container d-flex justify-content-end">
            <?php echo e($questions->links()); ?>

        </div>
    </div>
</div>

<script>
    var currentTitle = 'My Thread';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\readit\resources\views/myquestion.blade.php ENDPATH**/ ?>