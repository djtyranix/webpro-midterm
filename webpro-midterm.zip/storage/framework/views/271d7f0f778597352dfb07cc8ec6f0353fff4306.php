

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center align-items-center mt-3 mb-5">
    <div class="col-3 mr-5 mt-5">
        <h1>Welcome to ReadIt, <strong>commander</strong>.</h1>
        <h2 class="text-justify">You can ask everything here. Before asking, check if similar question is already answered here.</h2>
        <div class="my-5">
            <form action="<?php echo e(route('search')); ?>" method="GET">
                <div class="form-group has-search">
                    <span class="fa fa-search form-control-feedback fa-lg"></span>
                    <input type="text" name="key" class="form-control" placeholder="Search questions">
                </div>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

    <div class="col-3 ml-5">
        <div class="card">
            <div class="card-body">
                <h2 class="text-center mb-4">Ask the community!</h2>
                <form action="<?php echo e(route('ask')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" name ="title_question" placeholder="What is up? Tell us.">
                    </div>
                    <div class="form-group">
                        <textarea name="detail_question" class="form-control" id="detail_question" cols="15" rows="5" style="resize: none;" placeholder="Provide details for your issues/questions."></textarea>
                    </div>
                    <button class="btn btn-outline-primary btn-block">
                        <?php echo e(__('Submit')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-hoverable mb-4">
                <div class="card-body">     
                    <a style="text-decoration: none; color: #000;" class="stretched-link" href="<?php echo e(route('thread', $question->id)); ?>">
                        <div class="media flex-wrap w-100 align-items-center">
                            <div class="media-body truncate">
                                <h2><strong><?php echo e($question->title_question); ?></strong></h2>
                                <div class="text-muted">
                                    <a href="javascript:void(0)"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <?php echo e($question->name); ?></a> | 
                                    <?php if($question->updated_at > $question->created_at): ?>
                                    Last edit <?php echo e(Carbon\Carbon::parse($question->created_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                                    <?php else: ?>
                                        Posted on <?php echo e(Carbon\Carbon::parse($question->updated_at)->timezone("Asia/Jakarta")->format('M d, Y \a\t H:i')); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="text-muted">
                                    <div>Member since <strong><?php echo e(Carbon\Carbon::parse($question->user_created_at)->timezone("Asia/Jakarta")->format('M d, Y')); ?></strong></div>
                                </div>
                            </div>
                        </div>              
                    </a>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Pagination -->
<div class="row">
    <div class="col-md-12">
        <div class="container d-flex justify-content-end">
            <?php echo e($questions->links()); ?>

        </div>
    </div>
</div>

<script>
    var currentTitle = 'Home';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\webpro-midterm\resources\views/home.blade.php ENDPATH**/ ?>